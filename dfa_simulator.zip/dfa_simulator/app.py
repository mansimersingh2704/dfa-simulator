"""
DFA Simulator — Flask Web Application Backend
==============================================
Provides RESTful JSON API endpoints for:
- Serving the single-page application frontend
- Fetching demonstration presets (3 clean presets)
- Validating formal DFA 5-tuples
- Simulating input strings step-by-step

Author: CSET302 Automata Theory & Computability Project Team
"""

from __future__ import annotations

import os
from typing import Any, Dict
from flask import Flask, jsonify, render_template, request

from dfa import DFA, DFAValidationError

app = Flask(__name__, template_folder="templates", static_folder="static")

# -----------------------------------------------------------------------------
# 3 Simple Presets for Demonstration
# -----------------------------------------------------------------------------
PRESETS: Dict[str, Dict[str, Any]] = {
    "ends_with_01": {
        "id": "ends_with_01",
        "name": "Strings ending with '01'",
        "description": "Accepts any binary string over {0, 1} that ends with '01'.",
        "alphabet": ["0", "1"],
        "states": ["q0", "q1", "q2"],
        "start_state": "q0",
        "accepting_states": ["q2"],
        "transitions": {
            "q0": {"0": "q1", "1": "q0"},
            "q1": {"0": "q1", "1": "q2"},
            "q2": {"0": "q1", "1": "q0"},
        },
        "sample_inputs": ["01", "101", "1001", "00", "10", "111", ""],
    },
    "contains_101": {
        "id": "contains_101",
        "name": "Strings containing '101'",
        "description": "Accepts any binary string over {0, 1} containing '101' as a substring.",
        "alphabet": ["0", "1"],
        "states": ["s0", "s1", "s2", "s3"],
        "start_state": "s0",
        "accepting_states": ["s3"],
        "transitions": {
            "s0": {"0": "s0", "1": "s1"},
            "s1": {"0": "s2", "1": "s1"},
            "s2": {"0": "s0", "1": "s3"},
            "s3": {"0": "s3", "1": "s3"},
        },
        "sample_inputs": ["101", "01010", "1101", "1001", "111", "000", ""],
    },
    "even_zeros": {
        "id": "even_zeros",
        "name": "Even number of 0s",
        "description": "Accepts any binary string over {0, 1} with an even count of '0's (including zero '0's).",
        "alphabet": ["0", "1"],
        "states": ["q_even", "q_odd"],
        "start_state": "q_even",
        "accepting_states": ["q_even"],
        "transitions": {
            "q_even": {"0": "q_odd", "1": "q_even"},
            "q_odd": {"0": "q_even", "1": "q_odd"},
        },
        "sample_inputs": ["", "00", "11", "010", "1", "0", "0110"],
    },
}


# -----------------------------------------------------------------------------
# Frontend Route
# -----------------------------------------------------------------------------
@app.route("/")
def index():
    """Serves the single-page application frontend."""
    return render_template("index.html")


# -----------------------------------------------------------------------------
# Core API Endpoints
# -----------------------------------------------------------------------------
@app.route("/api/presets", methods=["GET"])
def get_presets():
    """Returns the list of simple demonstration presets."""
    return jsonify({"success": True, "presets": PRESETS})


@app.route("/api/validate", methods=["POST"])
def validate_dfa():
    """Validates a formal DFA definition 5-tuple."""
    data = request.get_json(force=True, silent=True)
    if not data:
        return jsonify({"success": False, "error": "Invalid request body: expected JSON."}), 400

    try:
        dfa_instance = DFA.from_dict(data, validate=True)
        return jsonify({
            "success": True,
            "message": "DFA definition is valid.",
            "dfa": dfa_instance.to_dict(),
            "edge_list": dfa_instance.to_transition_list(),
        })
    except DFAValidationError as e:
        return jsonify({"success": False, "error": str(e)}), 400
    except Exception as e:
        return jsonify({"success": False, "error": f"Validation error: {str(e)}"}), 400


@app.route("/api/simulate", methods=["POST"])
def simulate():
    """Simulates an input string step-by-step through the DFA."""
    data = request.get_json(force=True, silent=True)
    if not data:
        return jsonify({"success": False, "error": "Invalid request body: expected JSON."}), 400

    dfa_data = data.get("dfa")
    input_str = data.get("input_string", "")
    if dfa_data is None:
        return jsonify({"success": False, "error": "Missing 'dfa' configuration in request body."}), 400

    try:
        dfa_instance = DFA.from_dict(dfa_data, validate=True)
        result = dfa_instance.simulate(str(input_str))
        return jsonify({"success": True, "result": result.to_dict()})
    except DFAValidationError as e:
        return jsonify({"success": False, "error": str(e)}), 400
    except Exception as e:
        return jsonify({"success": False, "error": f"Simulation failure: {str(e)}"}), 400


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    print(f"Starting DFA Simulator on http://127.0.0.1:{port}")
    app.run(host="127.0.0.1", port=port, debug=True)
