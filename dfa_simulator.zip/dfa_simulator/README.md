# DFA Simulator — CSET302 Automata Theory & Computability

A clean, responsive, and beginner-friendly **Deterministic Finite Automaton (DFA) Simulator** designed for college coursework demonstration and viva evaluation in **CSET302 – Automata Theory and Computability**.

---

## 📌 Project Overview & Mathematical Model

A Deterministic Finite Automaton is formally defined as a 5-tuple:
$$M = (Q, \Sigma, \delta, q_0, F)$$
- **$Q$**: Finite, non-empty set of states.
- **$\Sigma$**: Finite, non-empty set of input symbols (alphabet).
- **$\delta$**: Transition function $\delta: Q \times \Sigma \to Q$.
- **$q_0$**: Unique initial / start state ($q_0 \in Q$).
- **$F$**: Set of final / accepting states ($F \subseteq Q$).

---

## ✨ Retained Core Features

1. **Create and Edit DFA**:
   - Define custom states $Q$ and alphabet $\Sigma$.
   - Designate a unique start state $q_0 \in Q$ and one or more accepting states $F \subseteq Q$.
   - Interactive Canvas Graph: drag state nodes to reposition, set start state, toggle accepting states (double ring), and add/delete transitions.
   - Clean transitions: self-loops on nodes, curved arcs for two-way edges, and merged symbol labels (e.g., `0, 1`).
   - Direct inline editing in the Transition Matrix Table $\delta(q, \sigma)$.

2. **DFA Definition Validation**:
   - Ensures $Q \neq \emptyset$ and $\Sigma \neq \emptyset$.
   - Validates that $q_0 \in Q$ and $F \subseteq Q$.
   - Verifies all transitions use valid source states, target states, and alphabet symbols.
   - Rejects non-deterministic duplicate transitions.
   - Displays clear, actionable error messages for malformed definitions.

3. **Step-by-Step Simulation & Tape**:
   - Processes strings one symbol at a time.
   - Real-time tape display showing consumed, active, and remaining symbols.
   - Dynamic canvas highlighting of the active state and active transition edge.
   - Clear and prominent **ACCEPTED** (Green) or **REJECTED** (Red) verdict.
   - Step controls: **Run String**, **Step ▶**, **◀ Back**, and **⏮ Reset**.
   - Detailed step history table with $(q, \sigma, \delta(q, \sigma))$ transition records.

4. **3 Simple Demonstration Presets**:
   - **Strings ending with '01'**: 3 states over alphabet $\{0, 1\}$.
   - **Strings containing '101'**: 4 states over alphabet $\{0, 1\}$.
   - **Even number of 0s**: 2 states over alphabet $\{0, 1\}$.

5. **Clean Dual-Mode Architecture**:
   - Communicates with the Flask REST API backend (`/api/validate`, `/api/simulate`, `/api/presets`).
   - Transparent client-side JavaScript fallback engine if running offline.

---

## 📂 Project Structure

```text
dfa-simulator/
├── app.py                         # Flask web API backend and routes
├── dfa.py                         # Core DFA mathematical engine and simulation
├── requirements.txt               # Dependencies (Flask, pytest)
├── README.md                      # Documentation and run instructions
├── templates/
│   └── index.html                 # Single-page application frontend
├── static/
│   ├── style.css                  # Clean indigo & amber styling (with Dark Mode)
│   └── app.js                     # Canvas visual editor & client simulator
└── tests/
    ├── test_dfa.py                # Core DFA validation & simulation tests (10 tests)
    ├── test_api.py                # Flask API endpoint tests (6 tests)
    └── test_cross_verification.py # Python vs JS cross-engine verification tests (1 test)
```

---

## 🚀 Setup and Run Instructions

### 1. Prerequisites
- Python 3.10+ (tested on Python 3.14)
- A modern web browser (Chrome, Edge, Firefox, Safari)

### 2. Install Dependencies
```bash
pip install -r requirements.txt
```

### 3. Run the Web Application
```bash
python app.py
```
Open your browser and navigate to:
```text
http://127.0.0.1:5000
```

### 4. Run Pytest Test Suite
To run all 17 unit, API, and cross-verification tests:
```bash
python -m pytest tests/ -v
```

---

## 🎓 Viva Demonstration Walkthrough

1. **Preset Demonstration**:
   - Select **"Strings ending with '01'"** from the dropdown and click **Load Preset**.
   - Click the sample input chips (e.g. `01`, `1001`, `00`, `ε`) to demonstrate both accepted and rejected inputs.

2. **Visual Editor Interaction**:
   - Drag states across the canvas to adjust graph layout.
   - Add a new state (e.g. `q3`) and a transition using the toolbar controls.
   - Click a state to toggle its final state status or change the start state.

3. **Step-by-Step Simulation**:
   - Enter `1001` in the input string field.
   - Click **Step ▶** repeatedly:
     - Observe the pointer on the tape cells.
     - Observe the active state circle and transition arrow light up in warm amber.
     - Observe each step appended to the transition table.
     - On reaching the end of the string, observe the prominent **ACCEPTED** badge.
   - Test a rejected string like `10` to demonstrate the **REJECTED** verdict.
